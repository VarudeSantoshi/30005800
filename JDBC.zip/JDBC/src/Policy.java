import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class Policy {

    public void InsertData(){

        Scanner sc=new Scanner(System.in);
        // variable declaration
        int PolicyID;
        String PolicyNumber;
        String Type;
        Double CoverageAmount;
        Double  PremiumAmount;
        System.out.println("enter PolicyID");
        PolicyID=sc.nextInt();
        System.out.println("enter PolicyNumber");
        PolicyNumber = sc.next();
        System.out.println("enter Type");
        Type=sc.next();
        System.out.println("enter CoverageAmount");
        CoverageAmount=sc.nextDouble();
        System.out.println("enter PremiumAmount");
        PremiumAmount=sc.nextDouble();



        try {
            //connection building
            Connection obj = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            System.out.println(obj);
            System.out.println("Successful Connection");

            //1 adding data
            //query to insert data
            PreparedStatement ps = obj.prepareStatement("insert into Policy values(?,?,?,?,?)");


            //setting values
            ps.setInt(1,PolicyID);
            ps.setString(2,PolicyNumber);
            ps.setString(3,Type);
            ps.setDouble(4,CoverageAmount);
            ps.setDouble(5,PremiumAmount);

            int i = ps.executeUpdate();
            if (i > 0) {
                System.out.println("Success");
            } else {
                System.out.println("Fail");
            }

        }catch (Exception e){
            e.printStackTrace();
        }
   }
    public void UpdateData(){
        Scanner sc = new Scanner(System.in);
        int PolicyID;
        String PolicyNumber;
        String Type;
        Double CoverageAmount;
        Double  PremiumAmount;

        System.out.println("enter PolicyID");
        PolicyID=sc.nextInt();
        System.out.println("set PolicyNumber");
        PolicyNumber = sc.next();
        System.out.println("set Type");
        Type=sc.next();
        System.out.println("set CoverageAmount");
        CoverageAmount=sc.nextDouble();
        System.out.println("set PremiumAmount");
        PremiumAmount=sc.nextDouble();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("update Policy set PolicyNumber=?,Type=?,CoverageAmount=?,PremiumAmount=? where PolicyID=?");

            ps.setString(1,PolicyNumber);
            ps.setString(2,Type);
            ps.setDouble(3,CoverageAmount);
            ps.setDouble(4,PremiumAmount);
            ps.setInt(5,PolicyID);



            int count = ps.executeUpdate();
            if (count > 0) {
                System.out.println("Update Successful");
            } else {
                System.out.println("Update cancel");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void DeleteData(){
        Scanner sc = new Scanner(System.in);
        int PolicyID;


        System.out.println("enter name");
        PolicyID = sc.nextInt();

        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("delete from Policy where PolicyID=?");

            ps.setInt(1, PolicyID);

            int count = ps.executeUpdate();
            if (count > 0) {
                System.out.println("deletion Successful");
            } else {
                System.out.println("deletion cancel");
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    public void FetchData(){
        try {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/healthinsurancepollicy", "root", "Santoshi3018");
            PreparedStatement ps = con.prepareStatement("select * from Policy");
            ResultSet rs = ps.executeQuery();
            System.out.println("PolicyID"+"\t\t"+"PolicyNumber"+"\t\t"+"Type"+"\t\t\t"+"CoverageAmount"+"\t\t\t"+"PremiumAmount");
            while (rs.next()) {


                int PolicyID = rs.getInt("PolicyID");
                String PolicyNumber = rs.getString("PolicyNumber");
                String Type =rs.getString("Type");
                Double CoverageAmount =rs.getDouble("CoverageAmount");
                Double PremiumAmount =rs.getDouble("PremiumAmount");

                System.out.println(PolicyID+"\t\t\t\t"+PolicyNumber+"\t\t\t\t"+Type+"\t\t\t\t"+CoverageAmount+"\t\t\t\t"+PremiumAmount);

            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }

}
