import java.util.Scanner;

public class Main extends Policy {
    public static void main(String[] args) {
        Policy p = new Policy();
        Member m = new Member();
        Claim c  = new Claim();
        Scanner sc = new Scanner(System.in);
        int num;
        do{
            System.out.println("Main menu");
            System.out.println("1. Policy Management");
            System.out.println("2. Member Management");
            System.out.println("3. Claim Management");
            System.out.println("4. Exit");
            System.out.println("Enter your choice");
            num=sc.nextInt();
            switch (num){
                // case 1 policy management
                case 1:
                    int PolicyChoice;
                    do {
                        System.out.println("1. Add a new Policy ");
                        System.out.println("2. Upadate Policy Information");
                        System.out.println("3. Delete Policy");
                        System.out.println("4. View Policy details");
                        System.out.println("5. Exit");
                        System.out.println("Choose work to be done");
                        PolicyChoice=sc.nextInt();
                        switch (PolicyChoice){
                            case 1:
                                System.out.println("add policy");
                                p.InsertData();
                                break;
                            case 2:
                                System.out.println("Upadate Policy");
                                p.UpdateData();
                                break;
                            case 3:
                                System.out.println("delete Policy");
                                p.DeleteData();
                                break;
                            case 4:
                                System.out.println("View Policy details");
                                p.FetchData();
                                break;
                            case 5:break;
                            default:
                                System.out.println("invalid choice");
                        }
                    }while (PolicyChoice <= 3);
                    break;



                // case 2 Memebr Management
                case 2:
                    int Memberchoice;
                    do {
                        System.out.println("1. Register a new Member ");
                        System.out.println("2. Upadate Member Information");
                        System.out.println("3. delete Member");
                        System.out.println("4. View Member details");
                        System.out.println("5. Exit");

                        System.out.println("Choose work to be done");
                        Memberchoice=sc.nextInt();
                        switch (Memberchoice){
                            case 1:
                                System.out.println("add Member");
                                m.InsertData();
                                break;
                            case 2:
                                System.out.println("Upadate Member");
                                m.UpdateData();
                                break;
                            case 3:
                                System.out.println("delete Member");
                                m.DeleteData();
                                break;
                            case 4:
                                System.out.println("View Member details");
                                m.FetchData();
                                break;
                            case 5:break;

                            default:
                                System.out.println("invalid choice");
                        }
                    }while (Memberchoice <= 3);
                    break;



                // case 2 Claim Management
                case 3:
                    int Claimchoice;
                    do {
                        System.out.println("1. Submit a new Claim ");
                        System.out.println("2. Upadate Claim");
                        System.out.println("3. delete Claim");
                        System.out.println("4. View Claim details");
                        System.out.println("5. Exit");

                        System.out.println("Choose work to be done");
                        Claimchoice=sc.nextInt();
                        switch (Claimchoice){
                            case 1:
                                System.out.println("add Claim");
                                c.InsertData();
                                break;
                            case 2:
                                System.out.println("Upadate Claim");
                                c.UpdateData();
                                break;
                            case 3:
                                System.out.println("delete Claim");
                                c.DeleteData();
                                break;
                            case 4:
                                System.out.println("View Member Claim");
                                c.FetchData();
                                break;
                            case 5:break;

                            default:
                                System.out.println("invalid choice");
                        }
                    }while (Claimchoice <= 3);
                    break;

                case 4:System.exit(0);
                default:
                    System.out.println("invalid choice");

            }


        }while (num <= 3);
    }
}
